package com.example.pcfactory.dto;

import java.util.List;

import lombok.Data;

@Data
public class ProductosDTO {
    private Integer id;
    private String nombre_producto;
    private Double precioUnitario;
    private String procesador;
    private String memoria_ram;
    private String almacenamiento;
    private String tipoProducto;
    private String marca;
    private List<String> ventas;
}
