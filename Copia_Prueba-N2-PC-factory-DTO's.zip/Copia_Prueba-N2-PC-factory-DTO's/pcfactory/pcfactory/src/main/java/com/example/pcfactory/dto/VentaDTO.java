package com.example.pcfactory.dto;

import java.time.LocalDateTime;
import java.util.List;


import lombok.Data;

@Data
public class VentaDTO {
    private Integer idVenta;
    private LocalDateTime fecha;
    private Double total;
    private List<String> productos;
    private String cliente;
    private String sucursal;
    private String tipoPago;
    private String tipoVenta;
    private String tipoDespacho;

}
