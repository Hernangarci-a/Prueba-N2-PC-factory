package com.example.pcfactory.dto;

import java.util.List;

import lombok.Data;

@Data
public class ClienteDTO {
    private Integer idCliente;
    private String rut;
    private String nombreCliente;
    private String apellidoCliente;
    private String correo;
    private String direccion;
    private String telefono;
    private List<String> ventas;
    private String comuna;
}
