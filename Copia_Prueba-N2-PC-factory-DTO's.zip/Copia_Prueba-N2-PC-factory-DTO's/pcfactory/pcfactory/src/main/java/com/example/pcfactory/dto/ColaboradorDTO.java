package com.example.pcfactory.dto;

import java.util.List;

import lombok.Data;

@Data
public class ColaboradorDTO {
    private Integer idColaborador;
    private String nombreColaborador;
    private String rutColaborador;
    private String correo;
    private String telefono;
    private Boolean activo;
    private List<String> sucursales;
    private List<String> tipoColaborador;
}
